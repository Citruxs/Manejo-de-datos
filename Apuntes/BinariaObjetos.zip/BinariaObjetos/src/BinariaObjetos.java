import static java.lang.System.*;
/**
 * BinariaObjetos.java
 * Clase que ilustra el algoritmo de b�squeda binaria.
 * <br>Esta versi�n trabaja solo con objetos
 * @author Gerardo Avil�s Rosas
 * @version Octubre de 2020
 */
public class BinariaObjetos{
  /**
    * M�todo de b�squeda binaria en un arreglo ordenado de objetos
    * @param datos El arreglo ordenado con objetos
    * @param buscado El objeto  buscado
    * @return int La posicion en donde se encuentra el objeto o bien -1 si no 
                  est� en el arreglo.
    */
  public static<T> int bbinariaO(T datos[],T buscado,java.util.Comparator<T> cmp){
    int maximo,minimo;
    maximo = datos.length - 1; //L�mite superior
    minimo = 0; //L�mite inferior
    return bbinariaO(datos,minimo,maximo,buscado,cmp);
  }
  
   /*
    * M�todo privado para implementar b�squeda binaria en un arreglo ordenado de objetos
    * @param datos El arreglo ordenado con objetos
    * @param minimo El l�mite inferior
    * @param maximo El l�mite superior 
    * @param buscado El objeto buscado
    * @return int La posicion en donde se encuentra el objeto o bien -1 si no 
                  est� en el arreglo.
    */
  private static<T> int bbinariaO(T datos[],int minimo,int maximo,T buscado,java.util.Comparator<T> cmp){
    int mitad;
    if (maximo >= 0 && cmp.compare(datos[minimo],buscado) <= 0 && 
                       cmp.compare(datos[maximo],buscado) >= 0){
      mitad = getMitad(minimo,maximo); //Obtenemos la mitad
      if (datos[mitad].equals(buscado)) //Si el valor buscado est� a la mitad
        return mitad;
      else if(cmp.compare(buscado,datos[mitad]) > 0) //Si el valor buscado es mayor que el de la mitad
        return bbinariaO(datos,mitad + 1,maximo,buscado,cmp); //Buscar en la mitad superior
      return bbinariaO(datos,minimo,mitad - 1,buscado,cmp); //Buscar en la mitad inferior
    }
    return -1; //No se encontr�
  }
  
  /*
   * M�todo privado para obtener el valor a la mitad del arreglo
   * @param minimo El l�mite inferior del arreglo
   * @param maximo El l�mite superior del arreglo
   * @return int El indice que est� a la mitad
   */
  private static int getMitad(int minimo, int maximo){
    return (maximo + minimo) / 2;
  }
  
  /**
   * M�todo que implementa el ordenamiento por algoritmo de la Burbuja
   * @param datos[] Un arreglo con los datos que se van a ordenar
   * @param cmp El comparador que se requiere para establecer relaci�n de orden
   * @return T[] Un arreglo con los objetos ordenados
   */
  public static <T> T[] bubblesort(T datos[], java.util.Comparator<T> cmp){
    T orden[] = datos;
    for(int i = 0;i < orden.length;i++)
      for(int j = i + 1; j < orden.length; j++)
        if (cmp.compare(datos[i],datos[j]) > 0 ){   //Los datos estan desordenados
          T temp = orden[i];                        //por tanto los intercambia
          orden[i] = orden[j];
          orden[j] = temp;
        }
    return orden;
  }
  
  /**
    * M�todo donde se utiliza la prueba del algoritmo
    * @param args[] Un arreglo de cadenas
    */
  public static void main(String[] args) throws java.text.ParseException{
    Persona datos[] = {new Persona("Sa�l Gaona","24/10/1986",15000),
                       new Persona("Juan P�rez","12/12/1986",5000),
                       new Persona("Pedro L�pez","18/06/1983",8000),
                       new Persona("Mar�a Rodr�guez","02/03/1989",9000),
                       new Persona("Laura S�nchez","15/07/1979",12000),
                       new Persona("Carlos Hern�ndez","24/09/1964",8000),
                       new Persona("Patricia Rosas","12/12/1986",15000),
                       new Persona("Iv�n Lara","01/11/1978",8000),
                       new Persona("Leticia Rivera","03/11/1986",13500),
                       new Persona("Andr�s Puente","05/10/1986",8000),
                       new Persona("Sandra Ch�vez","17/09/1986",4600)};
    //Ordenar con respecto a la edad
    out.println("\nOrdenamos el arreglo de forma ascendente con respecto a la edad y el nombre:");
    Persona orden[] = bubblesort(datos,new ComparaEdadNombre());
    out.println("Buscamos algunos elementos:");
    out.println("Alma S�nchez se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Alma S�nchez","05/06/1987",10000),new ComparaEdadNombre()));
    out.println("Patricia Rosas se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Patricia Rosas","12/12/1986",15000),new ComparaEdadNombre()));
    out.println("Carlos Hern�ndez se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Carlos Hern�ndez","24/09/1964",8000),new ComparaEdadNombre()));
    out.println("Juan P�rez se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Juan P�rez","12/12/1986",5000),new ComparaEdadNombre()));
    out.println("Andr�s Puente se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Andr�s Puente","05/10/1986",8000),new ComparaEdadNombre()));
    //Ordenar con respecto al salario
    out.println("\nOrdenamos el arreglo de forma ascendente con respecto al salario:");
    orden = bubblesort(datos,new ComparaSalario());
    out.println("Buscamos algunos elementos:");
    out.println("Alma S�nchez se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Alma S�nchez","05/06/1987",10000),new ComparaSalario()));
    out.println("Patricia Rosas se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Patricia Rosas","12/12/1986",15000),new ComparaSalario()));
    out.println("Carlos Hern�ndez se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Carlos Hern�ndez","24/09/1964",8000),new ComparaSalario()));
    out.println("Juan P�rez se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Juan P�rez","12/12/1986",5000),new ComparaSalario()));
    out.println("Andr�s Puente se encuentra en la posici�n "+ 
        bbinariaO(orden,new Persona("Andr�s Puente","05/10/1986",8000),new ComparaSalario()));
  }
}