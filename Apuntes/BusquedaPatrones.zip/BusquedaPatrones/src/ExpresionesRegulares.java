import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
/**
 * ExpresionesRegulares.java
 * Clase que ilustra el uso de expresiones regurales
 */
public class ExpresionesRegulares{
  public static void main(String [] args){
    String cadena,email;
    Pattern pat;
    Matcher mat;
    Scanner lector = new Scanner(System.in);
    //1. Comprobar si el String cadena contiene exactamente el patr�n (matches) �abc�
    cadena = "Hola a todos abc adi�s";
    pat = Pattern.compile("abc");
    mat = pat.matcher(cadena);
    if (mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //2. Comprobar si el String cadena contiene �abc�
    pat = Pattern.compile(".*abc.*");
    mat = pat.matcher(cadena);                                                                           
    if (mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //Tambi�n lo podemos escribir usando el m�todo find:
    pat = Pattern.compile("abc");
    mat = pat.matcher(cadena);
    if(mat.find())
      System.out.println("V�lido");                                                                            
    else
      System.out.println("No V�lido");
    //3. Comprobar si el String cadena empieza por �abc�
    pat = Pattern.compile("^abc.*");
    mat = pat.matcher(cadena);
    if(mat.matches())
      System.out.println("V�lido");                                                                            
    else
      System.out.println("No V�lido");
    //4. Comprobar si el String cadena empieza por �abc� � �Abc�
    pat = Pattern.compile("^[aA]bc.*");
    mat = pat.matcher(cadena);                                                                           
    if (mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //5. Comprobar si el String cadena est� formado por un m�nimo de 5 letras may�sculas 
    //   o min�sculas y un m�ximo de 10.
    pat = Pattern.compile("[a-zA-Z]{5,10}");
    mat = pat.matcher(cadena);                                                                           
    if (mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //6. Comprobar si el String cadena no empieza por un d�gito
    pat = Pattern.compile("^[^\\d].*");
    mat = pat.matcher(cadena);                                                                           
    if (mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //7. Comprobar si el String cadena no acaba con un d�gito
    pat = Pattern.compile(".*[^\\d]$");
    mat = pat.matcher(cadena);                                                                           
    if (mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //8. Comprobar si el String cadena solo contienen los caracteres a � b
    pat = Pattern.compile("(a|b)+");
    mat = pat.matcher(cadena);                                                                           
    if(mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //9. Comprobar si el String cadena contiene un 1 y ese 1 no est� seguido por un 2
    pat = Pattern.compile(".*1(?!2).*");
    mat = pat.matcher(cadena);                                                                           
    if(mat.matches())
      System.out.println("SI");
    else
      System.out.println("NO");
    //10. Expresi�n regular para comprobar si un email es v�lido
    System.out.print("Introduce email: ");
    email = lector.next();
    pat = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");   
    mat = pat.matcher(email);
    if(mat.find())
      System.out.println("Correo V�lido");
    else
      System.out.println("Correo No V�lido");
    /*
    El m�todo split de la clase String es la alternativa a usar StringTokenizer para separa 
    cadenas. Este m�todo divide el String en cadenas seg�n la expresi�n regular que recibe. 
    La expresi�n regular no forma parte del arreglo resultante.
     */
    String str = "blanco-rojo:amarillo.verde_azul";
    String cadenas[] = str.split("[-:._]");                                                                     
    for(int i = 0; i<cadenas.length; i++)
      System.out.println(cadenas[i]);
    //Segundo ejemplo
    str = "esto es un ejemplo de como funciona split";
    cadenas = str.split("(e[s|m])|(pl)");                                                              
    for(int i = 0; i<cadenas.length; i++)
      System.out.println(cadenas[i]);
  }
}