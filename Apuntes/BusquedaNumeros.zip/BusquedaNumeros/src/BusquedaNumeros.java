import static java.lang.System.*;
/**
 * BusquedaNumeros.java
 * Clase que ilustra el algoritmo de b�squeda secuencial (datos ordenados y sin ordenar).
 * <br>Esta versi�n trabaja solo con valores num�ricos
 * @author Gerardo Avil�s Rosas
 * @version Octubre de 2020
 */
public class BusquedaNumeros{
  /**
    * M�todo de b�squeda secuencial en un arreglo de enteros
    * @param datos El arreglo con datos enteros
    * @param buscado El n�mero  buscado
    * @return int La posicion en donde se encuentra el dato o bien -1 si no 
                  est� en el arreglo.
    */
  public static int busquedaS(int[] datos, int buscado){
    for (int i = 0; i < datos.length; i++)
      if(datos[i] == buscado)
        return i;
    return  -1;
  }
  
  /**
    * M�todo de busqueda secuencial en un arreglo de enteros ordenados
    * @param datos El arreglo ordenado con datos
    * @param buscado El dato buscado
    * @return int La posicion en donde se encuentra el dato o bien -1 si no 
                est� en el arreglo.
    */
  public static int busquedaSO(int datos[], int buscado){
    for (int i = 0; i < datos.length ; i++)
      if(datos[i] == buscado)
        return i;
      else if(datos[i] > buscado)
        return -1;
    return  -1;
  }
  
  /**
    * M�todo que implementa el ordenamiento por algoritmo de la Burbuja
    * @param datos[] Un arreglo con los datos que se van a ordenar
    * @return int[] Un arreglo con los datos ordenados
    */
  public static int[] bubblesort(int datos[]){
    int orden[] = datos;
    for(int i = 0;i < orden.length;i++)
      for(int j = i + 1; j < orden.length; j++)
        if(orden[i] > orden[j]){   //Los datos estan desordenados por tanto
          int temp = orden[i];     //los intercambia
          orden[i] = orden[j];
          orden[j] = temp;
        }
    return orden;
  }
  
  /**
    * M�todo donde se utiliza la prueba del algoritmo
    * @param args[] Un arreglo de cadenas
    */
  public static void main(String args[]){
    int[] datos = {78, 25, 89, 999, 98, 103, 4, 7897, 43};
    out.println("Buscamos algunos elementos:");
    out.println("El 45 se encuentra en la posici�n " + busquedaS(datos, 45));
    out.println("El 4 se encuentra en la posici�n " + busquedaS(datos, 4));
    out.println("El 999 se encuentra en la posici�n " + busquedaS(datos, 999));
    out.println("El 98 se encuentra en la posici�n " + busquedaS(datos, 98));
    out.println("\nOrdenamos el arreglo:");
    int ordenado[] = bubblesort(datos);
    out.println("Buscamos algunos elementos:");
    out.println("El 45 se encuentra en la posici�n " + busquedaSO(ordenado, 45));
    out.println("El 4 se encuentra en la posici�n " + busquedaSO(ordenado, 4));
    out.println("El 999 se encuentra en la posici�n " + busquedaSO(ordenado, 999));
    out.println("El 98 se encuentra en la posici�n " + busquedaSO(ordenado, 98));
  }
}