import java.text.DecimalFormat;
/**
 * ComparaSalario.java
 * Clase que permite implementar la interfaz Comparator
 * <br>En este caso la comparaci�n se hace por medio de la edad
 * @author Gerardo Avil�s Rosas
 * @version Octubre 2021
 */
public class ComparaSalario implements java.util.Comparator<Persona> {
  /**
   * M�todo que especifica la forma en c�mo se van a comparar los objetos
   * @param p1 Una de las personas para comparar
   * @param p2 Una de las personas para comparar
   * @return int 0 si son iguales, mayor a 0 si p1 es mayor que p2, menor a 0 si p2 es mayor que p1
   */
  public int compare(Persona p1, Persona p2){
    double difSalario = 0;
    if (p1 == p2) return 0;
    if(p1 == null) return -1;
    if(p2 == null) return 1;
    //Utilizamos el salario para realizar la comparaci�n
    try{
      difSalario = quitarFormato(p1.getSalario()) - quitarFormato(p2.getSalario());
    }
    catch(java.text.ParseException pe){}
    //Si se desea que las personas del mismo salario queden ordenadas por el nombre
    if (difSalario == 0)
      return p1.getNombre().compareTo(p2.getNombre());
   else
     return (int)difSalario;
  }
  
  private double quitarFormato(String c) throws java.text.ParseException{
    DecimalFormat formateador = new DecimalFormat("$###,###,###.##");
    return formateador.parse(c).doubleValue();
  }
}