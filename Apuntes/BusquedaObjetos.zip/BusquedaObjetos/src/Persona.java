import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Locale;
import java.text.NumberFormat;
import java.util.Calendar;
/**
 * Persona.java
 * Clase que permite modelar personas para probar ordenamiento de objetos
 * @author Gerardo Avil�s Rosas
 * @version Octubre 2021
 */
public class Persona{
  private String nombre;
  private Date fecha;
  private double salario;
  
  /**
   * Constructor por omisi�n de la clase Persona
   * @throws java.text.ParseException
   */
  public Persona() throws java.text.ParseException{
    nombre = "Juan P�rez";
    setFecha("10/11/1964");
    salario = 8000;
  }
  
  /**
   * Constructor por par�metros
   * @param n Una cadena con el nombre del cliente
   * @param d Una cadena con la fecha de nacimiento en el formato dd/mm/aaaa
   * @param s El salario de la persona
   * @throws java.text.ParseException
   */
  public Persona(String n,String d,double s) throws java.text.ParseException{
    setNombre(n);
    setFecha(d);
    setSalario(s);
  }
  
  /**
   * M�todo para obtener el nombre de la persona
   * @return String Una cadena con el nombre de la persona
   */
  public String getNombre(){
    return nombre;
  }
  
  /**
   * M�todo para obtener la fecha de una persona
   * @return String Una cadena con la fecha de nacimiento en formato dd/mm/aaaa
   */
  public String getFecha(){
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    String date = sdf.format(fecha);
    return date;
  }
  
  /**
   * M�todo para obtener el salario de la persona
   * @return String El salario de la persona en formato moneda
   */
  public String getSalario(){
    Locale locale = new Locale("es","MX");
    NumberFormat nf = NumberFormat.getCurrencyInstance(locale);
    return nf.format(salario);
  }
  
  /**
   * M�todo para establecer el nombre de la persona
   * @param n Una cadena con el nombre de la persona
   */
  public void setNombre(String n){
    nombre = n;
  }
  
  /**
   * M�todo para establecer la fecha de nacimiento de la persona
   * @param d Una cadena con la fecha de nacimiento de la persona en formato dd/mm/aaaa
   * @throws java.text.ParseException
   */
  public void setFecha(String d) throws java.text.ParseException{
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    fecha = sdf.parse(d);
  }
  
  /**
   * M�todo para establecer el salario de la persona
   * @param s El salario de la persona
   */
  public void setSalario(double s){
    salario = (s < 0)? 5000 : s;
  }
  
  /**
   * M�todo que permite calcular la edad de una persona
   * @return int La edad de la persona
   */
  public int edad(){
    Calendar fechaNac = Calendar.getInstance();
    DateFormat format=new SimpleDateFormat("dd/MM/yyyy");
    format.format(fecha);
    fechaNac = format.getCalendar();
    Calendar hoy = Calendar.getInstance();
    int diff_year = hoy.get(Calendar.YEAR) -  fechaNac.get(Calendar.YEAR);
    int diff_month = hoy.get(Calendar.MONTH) - fechaNac.get(Calendar.MONTH);
    int diff_day = hoy.get(Calendar.DAY_OF_MONTH) - fechaNac.get(Calendar.DAY_OF_MONTH);
    //Si est� en ese a�o pero todav�a no los ha cumplido
    if (diff_month < 0 || (diff_month == 0 && diff_day < 0))
      diff_year = diff_year - 1;
    return diff_year;
  }
  
  /**
   * M�todo para imprimir una persona en formato cadena
   * @return String Los datos de la persona
   */
  public String toString(){
    return "Nombre: " + nombre +
           "  |  Fecha nacimiento: " + getFecha() +
           "  |  Edad: " + edad() +
           "  |  Salario: " + getSalario() + "\n";
  }
}