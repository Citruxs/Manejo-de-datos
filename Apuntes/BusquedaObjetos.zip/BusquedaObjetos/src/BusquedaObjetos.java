import static java.lang.System.*;
/**
 * BurbujaObjetos.java
 * Clase que ilustra el algoritmo de b�squeda lineal (datos ordenados y no ordenados)
 * <br>Esta versi�n trabaja con objetos
 * @author Gerardo Avil�s Rosas
 * @version Agosto de 2020
 */
public class BusquedaObjetos{
  /**
    * M�todo de busqueda secuencial en un arreglo de objetos
    * @param datos El arreglo con objetos
    * @param buscado El objeto buscado
    * @return int La posicion en donde se encuentra el objeto o bien -1 si no 
                  est� en el arreglo.
    */
  public static <T> int busquedaS(T datos[],T buscado) {
    for (int i = 0; i < datos.length ; i++)
      if(datos[i].equals(buscado))
        return i;
    return -1;
  }
  
  /**
    * M�todo de busqueda secuencial en un arreglo de objetos ordenados
    * @param datos El arreglo ordenado con objetos
    * @param buscado El objeto buscado
    * @param cmp El comparador que se requiere para establecer relaci�n de orden
    * @return int La posicion en donde se encuentra el objeto o bien -1 si no 
                  est� en el arreglo.
    */
  public static <T> int busquedaSO(T datos[], T buscado,java.util.Comparator<T> cmp){
    for (int i = 0; i < datos.length ; i++)
      if(datos[i].equals(buscado))
        return i;
      else if(cmp.compare(datos[i],buscado) > 0 )
        return -1;
    return  -1;
  }
  
  /**
   * M�todo que implementa el ordenamiento por algoritmo de la Burbuja
   * @param datos[] Un arreglo con los datos que se van a ordenar
   * @param cmp El comparador que se requiere para establecer relaci�n de orden
   * @return T[] Un arreglo con los objetos ordenados
   */
  public static <T> T[] bubblesort(T datos[], java.util.Comparator<T> cmp){
    T orden[] = datos;
    for(int i = 0;i < orden.length;i++)
      for(int j = i + 1; j < orden.length; j++)
        if (cmp.compare(datos[i],datos[j]) > 0 ){   //Los datos estan desordenados
          T temp = orden[i];                        //por tanto los intercambia
          orden[i] = orden[j];
          orden[j] = temp;
        }
    return orden;
  }
  
  /**
    * M�todo donde se utiliza la prueba del algoritmo
    * @param args[] Un arreglo de cadenas
    */
  public static void main(String args[]) throws java.text.ParseException{
    Persona datos[] = {new Persona("Sa�l Gaona","24/10/1986",15000),
                       new Persona("Juan P�rez","12/12/1986",5000),
                       new Persona("Pedro L�pez","18/06/1983",8000),
                       new Persona("Mar�a Rodr�guez","02/03/1989",9000),
                       new Persona("Laura S�nchez","15/07/1979",12000),
                       new Persona("Carlos Hern�ndez","24/09/1964",8000),
                       new Persona("Patricia Rosas","12/12/1986",15000),
                       new Persona("Iv�n Lara","01/11/1978",8000),
                       new Persona("Leticia Rivera","03/11/1986",13500),
                       new Persona("Andr�s Puente","05/10/1986",8000),
                       new Persona("Sandra Ch�vez","17/09/1986",4600)};
    out.println("Buscamos algunos elementos:");
    out.println("Alma S�nchez se encuentra en la posici�n "+ 
                           busquedaS(datos,new Persona("Alma S�nchez","05/06/1987",10000)));
    out.println("Patricia Rosas se encuentra en la posici�n "+ 
                           busquedaS(datos,new Persona("Patricia Rosas","12/12/1986",15000)));
    out.println("Carlos Hern�ndez se encuentra en la posici�n "+ 
                           busquedaS(datos,new Persona("Carlos Hern�ndez","24/09/1964",8000)));
    out.println("Juan P�rez se encuentra en la posici�n "+ 
                           busquedaS(datos,new Persona("Juan P�rez","12/12/1986",5000)));
    out.println("Andr�s Puente se encuentra en la posici�n "+ 
                           busquedaS(datos,new Persona("Andr�s Puente","05/10/1986",8000)));
    //Ordenar con respecto a la edad
    out.println("\nOrdenamos el arreglo de forma ascendente con respecto a la edad y nombre:");
    Persona orden[] = bubblesort(datos,new ComparaEdadNombre());
    out.println("Buscamos algunos elementos:");
    out.println("Alma S�nchez se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Alma S�nchez","05/06/1987",10000),new ComparaEdadNombre()));
    out.println("Patricia Rosas se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Patricia Rosas","12/12/1986",15000),new ComparaEdadNombre()));
    out.println("Carlos Hern�ndez se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Carlos Hern�ndez","24/09/1964",8000),new ComparaEdadNombre()));
    out.println("Juan P�rez se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Juan P�rez","12/12/1986",5000),new ComparaEdadNombre()));
    out.println("Andr�s Puente se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Andr�s Puente","05/10/1986",8000),new ComparaEdadNombre()));
    //Ordenar con respecto al salario
    out.println("\nOrdenamos el arreglo de forma ascendente con respecto al salario:");
    orden = bubblesort(datos,new ComparaSalario());
    out.println("Buscamos algunos elementos:");
    out.println("Alma S�nchez se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Alma S�nchez","05/06/1987",10000),new ComparaSalario()));
    out.println("Patricia Rosas se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Patricia Rosas","12/12/1986",15000),new ComparaSalario()));
    out.println("Carlos Hern�ndez se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Carlos Hern�ndez","24/09/1964",8000),new ComparaSalario()));
    out.println("Juan P�rez se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Juan P�rez","12/12/1986",5000),new ComparaSalario()));
    out.println("Andr�s Puente se encuentra en la posici�n "+ 
        busquedaSO(orden,new Persona("Andr�s Puente","05/10/1986",8000),new ComparaSalario()));
  }
}