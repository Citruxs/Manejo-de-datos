import static java.lang.System.*;
/**
 * BinariaNumeros.java
 * Clase que ilustra el algoritmo de b�squeda binaria.
 * <br>Esta versi�n trabaja solo con valores num�ricos
 * @author Gerardo Avil�s Rosas
 * @version Octubre de 2020
 */
public class BinariaNumeros{
  /**
    * M�todo de b�squeda binaria en un arreglo ordenado de enteros
    * @param datos El arreglo ordenado con datos enteros
    * @param buscado El n�mero  buscado
    * @return int La posicion en donde se encuentra el dato o bien -1 si no 
                  est� en el arreglo.
    */
  public static int bbinaria(int datos[],int buscado){
    int maximo,minimo;
    maximo = datos.length - 1; //L�mite superior
    minimo = 0; //L�mite inferior
    return bbinaria(datos,minimo,maximo,buscado);
  }
  
   /*
    * M�todo privado para implementar b�squeda binaria en un arreglo ordenado de enteros
    * @param datos El arreglo ordenado con datos enteros
    * @param minimo El l�mite inferior
    * @param maximo El l�mite superior 
    * @param buscado El n�mero  buscado
    * @return int La posicion en donde se encuentra el dato o bien -1 si no 
                  est� en el arreglo.
    */
  private static int bbinaria(int datos[],int minimo,int maximo,int buscado){
    int mitad;
    if (maximo >= 0 && datos[minimo] <= buscado && datos[maximo] >= buscado){
      mitad = getMitad(minimo,maximo); //Obtenemos la mitad
      if (datos[mitad] == buscado) //Si el valor buscado est� a la mitad
        return mitad;
      else if(datos[mitad] < buscado) //Si el valor buscado es menor que el de la mitad
        return bbinaria(datos,mitad + 1,maximo,buscado); //Buscar en la mitad inferior
      return bbinaria(datos,minimo,mitad - 1,buscado); //Buscar en la mitad superior
    }
    return -1; //No se encontr�
  }
  
  /*
   * M�todo privado para obtener el valor a la mitad del arreglo
   * @param minimo El l�mite inferior del arreglo
   * @param maximo El l�mite superior del arreglo
   * @return int El indice que est� a la mitad
   */
  private static int getMitad(int minimo, int maximo){
    return (maximo + minimo) / 2;
  }
  
  /**
    * M�todo que implementa el ordenamiento por algoritmo de la Burbuja
    * @param datos[] Un arreglo con los datos que se van a ordenar
    * @return int[] Un arreglo con los datos ordenados
    */
  public static int[] bubblesort(int datos[]){
    int orden[] = datos;
    for(int i = 0;i < orden.length;i++)
      for(int j = i + 1; j < orden.length; j++)
        if(orden[i] > orden[j]){   //Los datos estan desordenados por tanto
          int temp = orden[i];     //los intercambia
          orden[i] = orden[j];
          orden[j] = temp;
        }
    return orden;
  }
  
  /**
    * M�todo donde se utiliza la prueba del algoritmo
    * @param args[] Un arreglo de cadenas
    */
  public static void main(String[] args){
    int datos[] = {5,15,120,40,10,100,20,500,400,200,2222,800,600};
    int ordenados[] = bubblesort(datos);
    out.println("Buscamos algunos elementos:");
    out.println("El 120 se encuentra en la posici�n " + bbinaria(ordenados, 120));
    out.println("El 400 se encuentra en la posici�n " + bbinaria(ordenados, 400));
    out.println("El 999 se encuentra en la posici�n " + bbinaria(ordenados, 999));
    out.println("El 800 se encuentra en la posici�n " + bbinaria(ordenados, 800));
  }
}